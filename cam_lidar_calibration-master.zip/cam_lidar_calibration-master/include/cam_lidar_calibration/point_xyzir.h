#ifndef POINTXYZIR_H
#define POINTXYZIR_H
#define PCL_NO_PRECOMPILE
#include <pcl/point_types.h>

// namespace pcl {
//  struct PointXYZIR
//  {
//   PCL_ADD_POINT4D;                    
//   float    intensity;                 
//   uint16_t ring;                      
//   EIGEN_MAKE_ALIGNED_OPERATOR_NEW     
//  }EIGEN_ALIGN16;
// }

// POINT_CLOUD_REGISTER_POINT_STRUCT(PointXYZIR,
//   (float, x, x)
//   (float, y, y)
//   (float, z, z)
//   (float, intensity, intensity)
//   (uint16_t, ring, ring))


namespace pcl {
 struct PointXYZIR
 {
 PCL_ADD_POINT4D;
 uint8_t intensity;
 uint8_t ring;
 //uint64_t timestamp;
 EIGEN_MAKE_ALIGNED_OPERATOR_NEW  // make sure our new allocators are aligned   
 }EIGEN_ALIGN16;
}
POINT_CLOUD_REGISTER_POINT_STRUCT(PointXYZIR,
                                  (float, x, x)(float, y, y)(float, z, z)
                                          (uint8_t, intensity, intensity)
                                          (uint8_t, ring, ring)
                                          )

#endif 
