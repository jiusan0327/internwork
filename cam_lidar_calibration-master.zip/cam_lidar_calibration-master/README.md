### Camera-Lidar auto calibration tool
For the detail， please see the blog：https://blog.csdn.net/AdamShan/article/details/105736726

### 相机-激光雷达自动化联合标定ROS工具
了解详情，请见博客：https://blog.csdn.net/AdamShan/article/details/105736726

### Calibration Result 一次标定的结果（用时5分钟)

![](images/demo.gif)